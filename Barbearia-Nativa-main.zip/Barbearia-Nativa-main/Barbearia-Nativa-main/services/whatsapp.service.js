const { default: makeWASocket, DisconnectReason, useMultiFileAuthState, fetchLatestBaileysVersion, jidNormalizedUser } = require('@whiskeysockets/baileys');
const fs = require('fs');
const path = require('path');
const QRCode = require('qrcode');

class WhatsAppService {
    constructor() {
        this.authDir = path.join(__dirname, '..', 'auth_info_baileys');
        this.sock = null;
        this.isConnected = false;
        this.isConnecting = false;
        this.currentQRCode = null;
        this.pairingCode = null; // NOVO: Código de pareamento
        this.reconnectTimeout = null;
        this.lastQRCode = null;
        this.connectionAttempts = 0;
        this.maxConnectionAttempts = 3;
        this.usePairingCode = false; // Modo de pareamento
        this.phoneNumber = null; // Número para pairing code
        
        // Garantir que o diretório de autenticação existe
        if (!fs.existsSync(this.authDir)) {
            fs.mkdirSync(this.authDir, { recursive: true });
        }

        // Inicializar arquivos de log se não existirem
        this.initializeLogFiles();
    }

    // Inicializar arquivos de log
    initializeLogFiles() {
        const logsPath = path.join(__dirname, '..', 'database', 'whatsapp_logs.json');
        const templatesPath = path.join(__dirname, '..', 'database', 'message_templates.json');

        if (!fs.existsSync(logsPath)) {
            fs.writeFileSync(logsPath, JSON.stringify([], null, 2));
        }

        if (!fs.existsSync(templatesPath)) {
            const defaultTemplates = {
                confirmation: "Olá {nome}! Seu agendamento para {data} às {horario} está confirmado. Serviço: {servico}",
                cancellation: "Olá {nome}! Infelizmente precisamos cancelar seu agendamento para {data} às {horario}. Motivo: {motivo}",
                reminder: "Olá {nome}! Lembrete: você tem um agendamento hoje às {horario} para {servico}"
            };
            fs.writeFileSync(templatesPath, JSON.stringify(defaultTemplates, null, 2));
        }
    }

    // Log de mensagens (com prevenção de duplicatas)
    logMessage(type, message) {
        const logsPath = path.join(__dirname, '..', 'database', 'whatsapp_logs.json');
        const logs = JSON.parse(fs.readFileSync(logsPath, 'utf8'));
        
        // Verificar se a última mensagem não é igual (evita spam)
        const lastLog = logs[logs.length - 1];
        const now = new Date();
        const timeDiff = lastLog ? (now - new Date(lastLog.timestamp)) : 10000;
        
        // Só adiciona se for mensagem diferente OU passou mais de 5 segundos
        if (!lastLog || lastLog.message !== message || timeDiff > 5000) {
            logs.push({
                timestamp: now.toISOString(),
                type: type,
                message: message
            });

            // Manter apenas os últimos 50 logs (reduzido de 100)
            if (logs.length > 50) {
                logs.splice(0, logs.length - 50);
            }

            fs.writeFileSync(logsPath, JSON.stringify(logs, null, 2));
        }
    }

    // Conectar ao WhatsApp (com opção de Pairing Code)
    async connect(phoneNumber = null) {
        if (this.isConnected) {
            console.log('✅ WhatsApp já está conectado');
            return { success: true, message: 'WhatsApp já está conectado' };
        }

        if (this.isConnecting) {
            console.log('⏳ Conexão já em andamento...');
            return { success: false, message: 'Conexão já em andamento' };
        }
        
        // Configurar modo de pareamento
        if (phoneNumber) {
            this.usePairingCode = true;
            this.phoneNumber = phoneNumber.replace(/\D/g, ''); // Apenas números
            console.log('📱 Modo Pairing Code ativado para:', this.phoneNumber);
        } else {
            this.usePairingCode = false;
            this.phoneNumber = null;
            console.log('📱 Modo QR Code ativado');
        }
        
        // Cancelar timeout de reconexão se existir
        if (this.reconnectTimeout) {
            clearTimeout(this.reconnectTimeout);
            this.reconnectTimeout = null;
        }

        try {
            this.isConnecting = true;
            const modo = this.usePairingCode ? 'Pairing Code' : 'QR Code';
            console.log(`🔄 Iniciando conexão com WhatsApp (${modo})...`);
            this.logMessage('info', `Iniciando conexão - ${modo}`);

            const { state, saveCreds } = await useMultiFileAuthState(this.authDir);
            const { version, isLatest } = await fetchLatestBaileysVersion();
            
            console.log(`📱 Usando versão do Baileys: ${version.join('.')}, é a mais recente: ${isLatest}`);

            this.sock = makeWASocket({
                version,
                auth: state,
                printQRInTerminal: false,
                browser: ['Barbearia Nativa', 'Chrome', '1.0.0'],
                // Timeouts otimizados para conexão mais rápida e estável
                connectTimeoutMs: 30000, // Reduzido de 60s
                keepAliveIntervalMs: 25000, // Mais frequente
                defaultQueryTimeoutMs: 30000, // Reduzido
                qrTimeout: 40000, // QR Code expira em 40s
                retryRequestDelayMs: 500, // Aumentado de 250ms
                maxMsgRetryCount: 2, // Reduzido de 3
                // Configurações otimizadas
                markOnlineOnConnect: false, // Não marcar online (mais leve)
                syncFullHistory: false,
                fireInitQueries: false,
                generateHighQualityLinkPreview: false,
                shouldSyncHistoryMessage: () => false,
                shouldIgnoreJid: () => false,
                getMessage: async (key) => undefined // Evitar buscar mensagens antigas
            });

            // IMPORTANTE: Configurar eventos ANTES de qualquer operação
            // Salvar credenciais automaticamente
            this.sock.ev.on('creds.update', saveCreds);
            
            // Eventos de mensagens
            this.sock.ev.on('messages.upsert', (m) => {
                const msg = m.messages[0];
                if (!msg.key.fromMe && m.type === 'notify') {
                    console.log('📨 Nova mensagem recebida:', msg.message?.conversation || 'Mídia');
                    this.logMessage('info', 'Nova mensagem recebida');
                }
            });
            
            // Solicitar pairing code se modo ativado
            if (this.usePairingCode && this.phoneNumber && !state.creds.registered) {
                console.log('📟 Solicitando pairing code para:', this.phoneNumber);
                
                // Aguardar socket estar pronto
                setTimeout(async () => {
                    try {
                        const code = await this.sock.requestPairingCode(this.phoneNumber);
                        this.pairingCode = code;
                        console.log('✅ Pairing Code gerado:', code);
                        this.logMessage('success', `Pairing Code gerado: ${code}`);
                    } catch (error) {
                        console.error('❌ Erro ao gerar pairing code:', error);
                        this.logMessage('error', `Erro ao gerar pairing code: ${error.message}`);
                    }
                }, 3000);
            }

            // Evento de atualização de conexão
            this.sock.ev.on('connection.update', async (update) => {
                const { connection, lastDisconnect, qr } = update;

                console.log('🔄 Connection update:', { connection, hasQR: !!qr });

                if (qr) {
                    // Gerar QR code em Base64 para o frontend (evitar duplicatas)
                    if (this.lastQRCode !== qr) {
                        try {
                            console.log('📱 Novo QR Code recebido, convertendo para Base64...');
                            const qrBase64 = await QRCode.toDataURL(qr);
                            this.currentQRCode = qrBase64;
                            this.lastQRCode = qr;
                            console.log('✅ QR Code gerado:', qrBase64.substring(0, 50) + '...');
                            this.logMessage('info', 'QR Code gerado - aguardando escaneamento');
                        } catch (error) {
                            console.error('❌ Erro ao gerar QR Code:', error);
                            this.logMessage('error', `Erro ao gerar QR Code: ${error.message}`);
                            this.currentQRCode = qr;
                        }
                    }
                }

                if (connection === 'open') {
                    console.log('✅ WhatsApp conectado com sucesso!');
                    this.isConnected = true;
                    this.isConnecting = false;
                    this.currentQRCode = null;
                    this.lastQRCode = null;
                    this.connectionAttempts = 0; // Reset tentativas
                    // Limpar timeout de reconexão se existir
                    if (this.reconnectTimeout) {
                        clearTimeout(this.reconnectTimeout);
                        this.reconnectTimeout = null;
                    }
                    this.logMessage('success', 'WhatsApp conectado com sucesso');
                    console.log('🔐 Sessão salva automaticamente');
                }

                if (connection === 'close') {
                    console.log('❌ Conexão fechada');
                    this.isConnected = false;
                    this.isConnecting = false;
                    this.currentQRCode = null;

                    const error = lastDisconnect?.error;
                    const statusCode = error?.output?.statusCode;
                    const errorMessage = error?.message || '';

                    console.log('🔍 Detalhes do erro:', {
                        statusCode,
                        error: errorMessage,
                        disconnectReason: DisconnectReason.loggedOut
                    });

                    // APENAS limpar sessão em logout REAL (403)
                    if (statusCode === 403 || statusCode === DisconnectReason.loggedOut) {
                        console.log('🚪 Logout REAL detectado - limpando sessão');
                        this.logMessage('warning', 'Logout do WhatsApp - sessão removida');
                        this.connectionAttempts = 0;
                        await this.clearSession();
                    } 
                    // Erros 401, 428, 515 - NÃO limpar sessão, tentar reconectar
                    else if (statusCode === 401 || statusCode === 428 || statusCode === 515 || statusCode === DisconnectReason.restartRequired) {
                        console.log('🔄 Erro temporário - tentando reconectar...');
                        this.logMessage('info', `Erro ${statusCode} - tentando reconectar`);
                        
                        // Cancelar timeout anterior se existir
                        if (this.reconnectTimeout) {
                            clearTimeout(this.reconnectTimeout);
                        }
                        
                        // Incrementar tentativas
                        this.connectionAttempts++;
                        
                        if (this.connectionAttempts <= this.maxConnectionAttempts) {
                            const delay = this.connectionAttempts * 5000; // 5s, 10s, 15s
                            console.log(`⏳ Aguardando ${delay/1000}s antes de reconectar (tentativa ${this.connectionAttempts}/${this.maxConnectionAttempts})`);
                            
                            this.reconnectTimeout = setTimeout(() => {
                                if (!this.isConnected && !this.isConnecting) {
                                    console.log('🔄 Reconectando...');
                                    this.connect();
                                }
                            }, delay);
                        } else {
                            console.log('❌ Máximo de tentativas atingido. Aguarde QR Code manual.');
                            this.logMessage('error', 'Máximo de tentativas de reconexão atingido');
                            this.connectionAttempts = 0;
                        }
                    } 
                    // Outros erros - sessão mantida
                    else {
                        console.log('❌ Conexão perdida - sessão mantida para reconexão manual');
                        this.logMessage('warning', 'Conexão perdida - reconexão manual necessária');
                    }
                }
            });

            return { success: true, message: 'Conexão iniciada - escaneie o QR Code' };

        } catch (error) {
            this.isConnecting = false;
            console.error('❌ Erro ao conectar:', error);
            this.logMessage('error', `Erro ao conectar: ${error.message}`);
            return { success: false, message: error.message };
        }
    }

    // Desconectar
    async disconnect() {
        try {
            if (this.sock) {
                console.log('🚪 Desconectando WhatsApp...');
                this.logMessage('info', 'Desconectando WhatsApp');
                await this.sock.logout();
                this.sock = null;
            }
            
            this.isConnected = false;
            this.isConnecting = false;
            this.currentQRCode = null;
            
            console.log('✅ WhatsApp desconectado');
            this.logMessage('success', 'WhatsApp desconectado');
            
            return { success: true, message: 'WhatsApp desconectado com sucesso' };
        } catch (error) {
            console.error('❌ Erro ao desconectar:', error);
            this.logMessage('error', `Erro ao desconectar: ${error.message}`);
            return { success: false, message: error.message };
        }
    }

    // Limpar sessão
    async clearSession() {
        try {
            console.log('🗑️ Limpando sessão...');
            
            // Desconectar primeiro
            await this.disconnect();
            
            // Remover arquivos de autenticação
            if (fs.existsSync(this.authDir)) {
                const files = fs.readdirSync(this.authDir);
                for (const file of files) {
                    fs.unlinkSync(path.join(this.authDir, file));
                }
                console.log('✅ Sessão limpa');
                this.logMessage('info', 'Sessão do WhatsApp limpa');
            }
            
        } catch (error) {
            console.error('❌ Erro ao limpar sessão:', error);
            this.logMessage('error', `Erro ao limpar sessão: ${error.message}`);
        }
    }

    // Enviar mensagem
    async sendMessage(to, message) {
        if (!this.isConnected || !this.sock) {
            throw new Error('WhatsApp não está conectado');
        }

        try {
            // Validar e formatar número
            const phoneNumber = to.replace(/\D/g, '');
            if (phoneNumber.length < 10) {
                throw new Error('Número de telefone inválido');
            }

            const jid = to.includes('@') ? to : `${phoneNumber}@s.whatsapp.net`;
            
            // Para números de teste (começam com 5511), pular verificação
            const isTestNumber = phoneNumber.startsWith('5511') && phoneNumber.length === 13;
            
            if (typeof message === 'object' && message !== null && Array.isArray(message.buttons)) {
                // Mensagem com botões (Baileys format) - aceitar aliases contentText/footerText
                const text = message.contentText || message.text || '';
                const footer = message.footerText || message.footer || '';
                const buttons = message.buttons;
                const payload = {
                    text: text,
                    footer: footer,
                    buttons: buttons
                };

                if (!isTestNumber) {
                    const [result] = await this.sock.onWhatsApp(jid);
                    if (!result?.exists) {
                        throw new Error(`Número ${phoneNumber} não está registrado no WhatsApp`);
                    }
                    await this.sock.sendMessage(result.jid, { text: payload.text, footer: payload.footer, buttons: payload.buttons });
                } else {
                    await this.sock.sendMessage(jid, { text: payload.text, footer: payload.footer, buttons: payload.buttons });
                }
            } else {
                // Texto simples
                if (!isTestNumber) {
                    // Verificar se o número existe no WhatsApp apenas para números reais
                    const [result] = await this.sock.onWhatsApp(jid);
                    if (!result?.exists) {
                        throw new Error(`Número ${phoneNumber} não está registrado no WhatsApp`);
                    }
                    await this.sock.sendMessage(result.jid, { text: String(message) });
                } else {
                    // Para números de teste, enviar diretamente
                    await this.sock.sendMessage(jid, { text: String(message) });
                }
            }
            
            console.log(`📤 Mensagem enviada para ${phoneNumber}`);
            this.logMessage('success', `Mensagem enviada para ${phoneNumber}`);
            
            return { 
                success: true, 
                message: 'Mensagem enviada com sucesso',
                recipient: phoneNumber
            };
        } catch (error) {
            console.error('❌ Erro ao enviar mensagem:', error);
            this.logMessage('error', `Erro ao enviar mensagem: ${error.message}`);
            throw error;
        }
    }

    // Obter status da conexão
    getStatus() {
        return {
            connected: this.isConnected,
            isConnected: this.isConnected,
            isConnecting: this.isConnecting,
            hasQRCode: !!this.currentQRCode,
            qrCode: this.currentQRCode,
            hasPairingCode: !!this.pairingCode,
            pairingCode: this.pairingCode,
            usePairingCode: this.usePairingCode
        };
    }

    // Obter QR code atual
    getCurrentQRCode() {
        return this.currentQRCode;
    }
    
    // Obter Pairing Code atual
    getPairingCode() {
        return this.pairingCode;
    }

    // Obter número conectado
    getConnectedUser() {
        if (this.isConnected && this.sock?.user) {
            return {
                id: this.sock.user.id,
                name: this.sock.user.name
            };
        }
        return null;
    }

    // Atualizar status do agendamento no arquivo (safe write)
    updateAppointmentStatus(appointmentId, status, note = '') {
        try {
            const agendamentosPath = path.join(__dirname, '..', 'database', 'agendamentos.json');
            if (!fs.existsSync(agendamentosPath)) {
                throw new Error('Arquivo de agendamentos não encontrado');
            }

            const agendamentos = JSON.parse(fs.readFileSync(agendamentosPath, 'utf8')) || [];
            const idx = agendamentos.findIndex(a => Number(a.id) === Number(appointmentId));
            if (idx === -1) {
                throw new Error('Agendamento não encontrado');
            }

            agendamentos[idx].status = status;
            if (status === 'confirmado') {
                agendamentos[idx].confirmado_em = new Date().toISOString();
            } else if (status === 'cancelado') {
                agendamentos[idx].cancelado_em = new Date().toISOString();
            }
            if (note) agendamentos[idx].observacoes = (agendamentos[idx].observacoes || '') + '\n' + note;

            fs.writeFileSync(agendamentosPath, JSON.stringify(agendamentos, null, 2));
            return true;
        } catch (error) {
            console.error('Erro ao atualizar agendamento:', error.message);
            throw error;
        }
    }
}

module.exports = WhatsAppService;